<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/typeUser')) {
            // listTypeUser
            if ($pathinfo === '/typeUsers') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_listTypeUser;
                }

                return array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::listTypeUserAction',  '_route' => 'listTypeUser',);
            }
            not_listTypeUser:

            // detailsTypeUser
            if (preg_match('#^/typeUser/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_detailsTypeUser;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'detailsTypeUser')), array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::detailsTypeUserAction',));
            }
            not_detailsTypeUser:

        }

        // deleteTypeUser
        if (0 === strpos($pathinfo, '/deleteTypeUser') && preg_match('#^/deleteTypeUser/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_deleteTypeUser;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'deleteTypeUser')), array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::deleteTypeUserAction',));
        }
        not_deleteTypeUser:

        if (0 === strpos($pathinfo, '/s')) {
            // saveTypeUser
            if ($pathinfo === '/saveTypeUser') {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_saveTypeUser;
                }

                return array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::saveTypeUserAction',  '_route' => 'saveTypeUser',);
            }
            not_saveTypeUser:

            if (0 === strpos($pathinfo, '/sousSecteur')) {
                // listSousSecteur
                if ($pathinfo === '/sousSecteurs') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_listSousSecteur;
                    }

                    return array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::listSousSecteurAction',  '_route' => 'listSousSecteur',);
                }
                not_listSousSecteur:

                // detailsSousSecteur
                if (preg_match('#^/sousSecteur/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_detailsSousSecteur;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'detailsSousSecteur')), array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::detailsSousSecteurAction',));
                }
                not_detailsSousSecteur:

            }

        }

        // deleteSousSecteur
        if (0 === strpos($pathinfo, '/deleteSousSecteur') && preg_match('#^/deleteSousSecteur/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_deleteSousSecteur;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'deleteSousSecteur')), array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::deleteSousSecteurAction',));
        }
        not_deleteSousSecteur:

        // saveSousSecteur
        if ($pathinfo === '/saveSousSecteur') {
            if ($this->context->getMethod() != 'POST') {
                $allow[] = 'POST';
                goto not_saveSousSecteur;
            }

            return array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::saveSousSecteurAction',  '_route' => 'saveSousSecteur',);
        }
        not_saveSousSecteur:

        if (0 === strpos($pathinfo, '/projet')) {
            // listProjet
            if ($pathinfo === '/projets') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_listProjet;
                }

                return array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::listProjetAction',  '_route' => 'listProjet',);
            }
            not_listProjet:

            // detailProjet
            if (preg_match('#^/projet/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_detailProjet;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'detailProjet')), array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::detailsProjetAction',));
            }
            not_detailProjet:

        }

        // deleteProjet
        if (0 === strpos($pathinfo, '/deleteProjet') && preg_match('#^/deleteProjet/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_deleteProjet;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'deleteProjet')), array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::deleteProjetAction',));
        }
        not_deleteProjet:

        if (0 === strpos($pathinfo, '/s')) {
            // saveProjet
            if ($pathinfo === '/saveProjet') {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_saveProjet;
                }

                return array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::saveProjetAction',  '_route' => 'saveProjet',);
            }
            not_saveProjet:

            if (0 === strpos($pathinfo, '/secteur')) {
                // listSecteurs
                if ($pathinfo === '/secteurs') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_listSecteurs;
                    }

                    return array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::listSecteurAction',  '_route' => 'listSecteurs',);
                }
                not_listSecteurs:

                // detailsSecteur
                if (preg_match('#^/secteur/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_detailsSecteur;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'detailsSecteur')), array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::detailsSecteurAction',));
                }
                not_detailsSecteur:

            }

        }

        // deleteSecteur
        if (0 === strpos($pathinfo, '/deleteSecteur') && preg_match('#^/deleteSecteur/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_deleteSecteur;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'deleteSecteur')), array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::deleteSecteurAction',));
        }
        not_deleteSecteur:

        // saveSecteur
        if ($pathinfo === '/saveSecteur') {
            if ($this->context->getMethod() != 'POST') {
                $allow[] = 'POST';
                goto not_saveSecteur;
            }

            return array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::saveSecteurAction',  '_route' => 'saveSecteur',);
        }
        not_saveSecteur:

        if (0 === strpos($pathinfo, '/user')) {
            // listUsers
            if ($pathinfo === '/users') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_listUsers;
                }

                return array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::listUserAction',  '_route' => 'listUsers',);
            }
            not_listUsers:

            // detailUser
            if (preg_match('#^/user/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_detailUser;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'detailUser')), array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::detailsUserAction',));
            }
            not_detailUser:

        }

        // deleteUser
        if (0 === strpos($pathinfo, '/deleteUser') && preg_match('#^/deleteUser/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_deleteUser;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'deleteUser')), array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::deleteUserAction',));
        }
        not_deleteUser:

        // saveUser
        if ($pathinfo === '/saveUser') {
            if ($this->context->getMethod() != 'POST') {
                $allow[] = 'POST';
                goto not_saveUser;
            }

            return array (  '_controller' => 'ClubProBundle\\Controller\\DefaultController::saveUserAction',  '_route' => 'saveUser',);
        }
        not_saveUser:

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
