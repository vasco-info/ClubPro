<?php

use Symfony\Component\Routing\RequestContext;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Psr\Log\LoggerInterface;

/**
 * appDevDebugProjectContainerUrlGenerator
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlGenerator extends Symfony\Component\Routing\Generator\UrlGenerator
{
    private static $declaredRoutes;

    /**
     * Constructor.
     */
    public function __construct(RequestContext $context, LoggerInterface $logger = null)
    {
        $this->context = $context;
        $this->logger = $logger;
        if (null === self::$declaredRoutes) {
            self::$declaredRoutes = array(
        '_wdt' => array (  0 =>   array (    0 => 'token',  ),  1 =>   array (    '_controller' => 'web_profiler.controller.profiler:toolbarAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'token',    ),    1 =>     array (      0 => 'text',      1 => '/_wdt',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_profiler_home' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'web_profiler.controller.profiler:homeAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/_profiler/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_profiler_search' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'web_profiler.controller.profiler:searchAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/_profiler/search',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_profiler_search_bar' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'web_profiler.controller.profiler:searchBarAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/_profiler/search_bar',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_profiler_info' => array (  0 =>   array (    0 => 'about',  ),  1 =>   array (    '_controller' => 'web_profiler.controller.profiler:infoAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'about',    ),    1 =>     array (      0 => 'text',      1 => '/_profiler/info',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_profiler_phpinfo' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/_profiler/phpinfo',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_profiler_search_results' => array (  0 =>   array (    0 => 'token',  ),  1 =>   array (    '_controller' => 'web_profiler.controller.profiler:searchResultsAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/search/results',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'token',    ),    2 =>     array (      0 => 'text',      1 => '/_profiler',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_profiler' => array (  0 =>   array (    0 => 'token',  ),  1 =>   array (    '_controller' => 'web_profiler.controller.profiler:panelAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'token',    ),    1 =>     array (      0 => 'text',      1 => '/_profiler',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_profiler_router' => array (  0 =>   array (    0 => 'token',  ),  1 =>   array (    '_controller' => 'web_profiler.controller.router:panelAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/router',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'token',    ),    2 =>     array (      0 => 'text',      1 => '/_profiler',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_profiler_exception' => array (  0 =>   array (    0 => 'token',  ),  1 =>   array (    '_controller' => 'web_profiler.controller.exception:showAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/exception',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'token',    ),    2 =>     array (      0 => 'text',      1 => '/_profiler',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_profiler_exception_css' => array (  0 =>   array (    0 => 'token',  ),  1 =>   array (    '_controller' => 'web_profiler.controller.exception:cssAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/exception.css',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'token',    ),    2 =>     array (      0 => 'text',      1 => '/_profiler',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        '_twig_error_test' => array (  0 =>   array (    0 => 'code',    1 => '_format',  ),  1 =>   array (    '_controller' => 'twig.controller.preview_error:previewErrorPageAction',    '_format' => 'html',  ),  2 =>   array (    'code' => '\\d+',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '.',      2 => '[^/]++',      3 => '_format',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => '\\d+',      3 => 'code',    ),    2 =>     array (      0 => 'text',      1 => '/_error',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'listTypeUser' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::listTypeUserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/typeUsers',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'detailsTypeUser' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::detailsTypeUserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/typeUser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'deleteTypeUser' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::deleteTypeUserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/deleteTypeUser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'saveTypeUser' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::saveTypeUserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/saveTypeUser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'listSousSecteur' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::listSousSecteurAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/sousSecteurs',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'detailsSousSecteur' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::detailsSousSecteurAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/sousSecteur',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'deleteSousSecteur' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::deleteSousSecteurAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/deleteSousSecteur',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'saveSousSecteur' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::saveSousSecteurAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/saveSousSecteur',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'listProjet' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::listProjetAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/projets',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'detailProjet' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::detailsProjetAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/projet',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'deleteProjet' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::deleteProjetAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/deleteProjet',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'saveProjet' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::saveProjetAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/saveProjet',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'listSecteurs' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::listSecteurAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/secteurs',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'detailsSecteur' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::detailsSecteurAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/secteur',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'deleteSecteur' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::deleteSecteurAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/deleteSecteur',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'saveSecteur' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::saveSecteurAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/saveSecteur',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'listUsers' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::listUserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/users',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'detailUser' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::detailsUserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/user',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'deleteUser' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::deleteUserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/deleteUser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'saveUser' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'ClubProBundle\\Controller\\DefaultController::saveUserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/saveUser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'homepage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
    );
        }
    }

    public function generate($name, $parameters = array(), $referenceType = self::ABSOLUTE_PATH)
    {
        if (!isset(self::$declaredRoutes[$name])) {
            throw new RouteNotFoundException(sprintf('Unable to generate a URL for the named route "%s" as such route does not exist.', $name));
        }

        list($variables, $defaults, $requirements, $tokens, $hostTokens, $requiredSchemes) = self::$declaredRoutes[$name];

        return $this->doGenerate($variables, $defaults, $requirements, $tokens, $parameters, $name, $referenceType, $hostTokens, $requiredSchemes);
    }
}
